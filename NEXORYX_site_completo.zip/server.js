const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, name: 'NEXORYX', message: 'Site online. Status de bots não é conectado a uma fonte real ainda.' });
});

// OAuth2 não é ativado automaticamente: configure as credenciais e a URL pública primeiro.
app.get('/api/auth/discord', (_req, res) => {
  const { DISCORD_CLIENT_ID, DISCORD_REDIRECT_URI } = process.env;
  if (!DISCORD_CLIENT_ID || !DISCORD_REDIRECT_URI) {
    return res.status(503).send('Login Discord ainda não configurado. Configure DISCORD_CLIENT_ID e DISCORD_REDIRECT_URI no ambiente do servidor.');
  }
  const url = new URL('https://discord.com/oauth2/authorize');
  url.searchParams.set('client_id', DISCORD_CLIENT_ID);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('redirect_uri', DISCORD_REDIRECT_URI);
  url.searchParams.set('scope', 'identify');
  res.redirect(url.toString());
});

app.get('/api/auth/discord/callback', (_req, res) => {
  res.status(501).send('Callback OAuth2 ainda não implementado. Configure a integração OAuth2 segura antes de usar login real.');
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, '0.0.0.0', () => console.log(`NEXORYX site listening on ${PORT}`));
